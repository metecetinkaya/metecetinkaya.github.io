
import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import RoomVisualizerApp from '@/components/RoomVisualizerApp';

function App() {
  return (
    <>
      <Helmet>
        <title>AI Room Designer - Transform Your Space with AI</title>
        <meta name="description" content="Upload your room photo and transform it with AI-powered interior design. Choose from Boho, Minimalist, Modern, and Scandinavian themes for stunning room visualizations." />
      </Helmet>
      <div className="min-h-screen">
        <RoomVisualizerApp />
        <Toaster />
      </div>
    </>
  );
}

export default App;
