
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Sparkles, Download, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import ImageUploader from '@/components/ImageUploader';
import ThemeSelector from '@/components/ThemeSelector';
import ResultDisplay from '@/components/ResultDisplay';

const RoomVisualizerApp = () => {
  const [uploadedImage, setUploadedImage] = useState(null);
  const [selectedTheme, setSelectedTheme] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [generatedImage, setGeneratedImage] = useState(null);
  const { toast } = useToast();

  const handleImageUpload = (file) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target.result);
        setGeneratedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerateDesign = async () => {
    if (!uploadedImage || !selectedTheme) {
      toast({
        title: "Missing Information",
        description: "Please upload an image and select a design theme first!",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setGeneratedImage(uploadedImage); // For demo purposes
      setIsProcessing(false);
      toast({
        title: "Design Generated! ✨",
        description: `Your room has been transformed with the ${selectedTheme} theme!`,
      });
    }, 3000);
  };

  const handleReset = () => {
    setUploadedImage(null);
    setSelectedTheme('');
    setGeneratedImage(null);
    setIsProcessing(false);
  };

  const handleDownload = () => {
    toast({
      title: "🚧 Download Feature",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-6xl font-bold gradient-text mb-4">
            AI Room Designer
          </h1>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Transform your space with the power of AI. Upload your room photo and watch it come to life with stunning design themes.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left Column - Controls */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Image Upload */}
            <div className="glass-effect rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-6">
                <Upload className="w-6 h-6 text-indigo-600" />
                <h2 className="text-2xl font-semibold text-gray-800">Upload Your Room</h2>
              </div>
              <ImageUploader 
                onImageUpload={handleImageUpload}
                uploadedImage={uploadedImage}
              />
            </div>

            {/* Theme Selection */}
            <div className="glass-effect rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-6 h-6 text-indigo-600" />
                <h2 className="text-2xl font-semibold text-gray-800">Choose Design Theme</h2>
              </div>
              <ThemeSelector 
                selectedTheme={selectedTheme}
                onThemeSelect={setSelectedTheme}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleGenerateDesign}
                disabled={!uploadedImage || !selectedTheme || isProcessing}
                className="generate-btn text-white font-semibold py-3 px-8 rounded-xl flex-1"
                size="lg"
              >
                {isProcessing ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
                    />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Generate Design
                  </>
                )}
              </Button>
              
              <Button
                onClick={handleReset}
                variant="outline"
                className="py-3 px-6 rounded-xl border-2"
                size="lg"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Reset
              </Button>
            </div>
          </motion.div>

          {/* Right Column - Results */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-6"
          >
            <ResultDisplay
              originalImage={uploadedImage}
              generatedImage={generatedImage}
              isProcessing={isProcessing}
              selectedTheme={selectedTheme}
              onDownload={handleDownload}
            />
          </motion.div>
        </div>

        {/* Features Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-16 grid md:grid-cols-3 gap-8"
        >
          {[
            {
              icon: "🎨",
              title: "AI-Powered Design",
              description: "Advanced AI algorithms transform your space while preserving the original layout"
            },
            {
              icon: "⚡",
              title: "Instant Results",
              description: "Get stunning room transformations in seconds with our lightning-fast processing"
            },
            {
              icon: "📱",
              title: "Mobile Friendly",
              description: "Design on any device with our fully responsive and intuitive interface"
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
              className="glass-effect rounded-2xl p-6 text-center"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default RoomVisualizerApp;
