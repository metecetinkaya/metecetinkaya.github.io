
import React from 'react';
import { motion } from 'framer-motion';

const themes = [
  {
    id: 'boho',
    name: 'Boho',
    description: 'Eclectic, colorful, and free-spirited design',
    colors: ['#D4A574', '#8B4513', '#CD853F', '#DEB887'],
    icon: '🌿'
  },
  {
    id: 'minimalist',
    name: 'Minimalist',
    description: 'Clean lines, neutral colors, and simplicity',
    colors: ['#FFFFFF', '#F5F5F5', '#E0E0E0', '#CCCCCC'],
    icon: '⚪'
  },
  {
    id: 'modern',
    name: 'Modern',
    description: 'Sleek, contemporary, and sophisticated',
    colors: ['#2C3E50', '#34495E', '#7F8C8D', '#BDC3C7'],
    icon: '🏢'
  },
  {
    id: 'scandinavian',
    name: 'Scandinavian',
    description: 'Light, airy, and functional Nordic design',
    colors: ['#F8F9FA', '#E9ECEF', '#ADB5BD', '#6C757D'],
    icon: '❄️'
  }
];

const ThemeSelector = ({ selectedTheme, onThemeSelect }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {themes.map((theme, index) => (
        <motion.div
          key={theme.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className={`theme-card rounded-xl p-4 cursor-pointer ${
            selectedTheme === theme.id ? 'selected' : ''
          }`}
          onClick={() => onThemeSelect(theme.id)}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-3">
            <span className="text-2xl">{theme.icon}</span>
            <h3 className="font-semibold text-gray-800">{theme.name}</h3>
          </div>
          
          <p className="text-sm text-gray-600 mb-3">{theme.description}</p>
          
          <div className="flex gap-2">
            {theme.colors.map((color, colorIndex) => (
              <div
                key={colorIndex}
                className="w-6 h-6 rounded-full border-2 border-white shadow-sm"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
          
          {selectedTheme === theme.id && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="mt-3 flex items-center justify-center"
            >
              <div className="w-6 h-6 bg-indigo-500 rounded-full flex items-center justify-center">
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            </motion.div>
          )}
        </motion.div>
      ))}
    </div>
  );
};

export default ThemeSelector;
