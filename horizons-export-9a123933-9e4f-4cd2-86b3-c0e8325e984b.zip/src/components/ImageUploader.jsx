
import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Image as ImageIcon, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ImageUploader = ({ onImageUpload, uploadedImage }) => {
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        if (file.size <= 10 * 1024 * 1024) { // 10MB limit
          onImageUpload(file);
        } else {
          toast({
            title: "File Too Large",
            description: "Please select an image smaller than 10MB.",
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please select a valid image file (JPG, PNG, etc.).",
          variant: "destructive",
        });
      }
    }
  };

  const handleDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      handleFileSelect({ target: { files: [file] } });
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const removeImage = () => {
    onImageUpload(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      {!uploadedImage ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="upload-zone rounded-xl p-8 text-center cursor-pointer"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-12 h-12 text-indigo-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            Drop your room photo here
          </h3>
          <p className="text-gray-500 mb-4">
            or click to browse your files
          </p>
          <p className="text-sm text-gray-400">
            Supports JPG, PNG up to 10MB
          </p>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="relative rounded-xl overflow-hidden bg-white shadow-lg"
        >
          <img
            src={uploadedImage}
            alt="Uploaded room"
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <Button
            onClick={removeImage}
            variant="destructive"
            size="sm"
            className="absolute top-3 right-3 rounded-full w-8 h-8 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
          <div className="absolute bottom-3 left-3 text-white">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              <span className="text-sm font-medium">Room uploaded</span>
            </div>
          </div>
        </motion.div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {!uploadedImage && (
        <Button
          onClick={() => fileInputRef.current?.click()}
          variant="outline"
          className="w-full py-3 rounded-xl border-2 border-dashed border-indigo-300 hover:border-indigo-500 transition-colors"
        >
          <Upload className="w-5 h-5 mr-2" />
          Choose File
        </Button>
      )}
    </div>
  );
};

export default ImageUploader;
