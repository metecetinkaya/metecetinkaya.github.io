
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Sparkles, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ResultDisplay = ({ 
  originalImage, 
  generatedImage, 
  isProcessing, 
  selectedTheme, 
  onDownload 
}) => {
  return (
    <div className="space-y-6">
      {/* Processing State */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="result-container rounded-2xl p-8 text-center processing"
          >
            <motion.div
              animate={{ 
                rotate: 360,
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                rotate: { duration: 2, repeat: Infinity, ease: "linear" },
                scale: { duration: 1, repeat: Infinity }
              }}
              className="w-16 h-16 mx-auto mb-4"
            >
              <Sparkles className="w-full h-full text-indigo-600" />
            </motion.div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              AI is working its magic ✨
            </h3>
            <p className="text-gray-600 mb-4">
              Transforming your room with {selectedTheme} design...
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-gradient-to-r from-indigo-500 to-purple-600 h-2 rounded-full"
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 3, ease: "easeInOut" }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Display */}
      <AnimatePresence>
        {(originalImage || generatedImage) && !isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="result-container rounded-2xl p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <ImageIcon className="w-6 h-6 text-indigo-600" />
              <h2 className="text-2xl font-semibold text-gray-800">
                {generatedImage ? 'Your Transformed Room' : 'Preview'}
              </h2>
            </div>

            <div className="space-y-6">
              {/* Before/After Comparison */}
              {generatedImage ? (
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-2">Original</h4>
                    <div className="rounded-xl overflow-hidden shadow-lg">
                      <img
                        src={originalImage}
                        alt="Original room"
                        className="w-full h-48 object-cover"
                      />
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-2">
                      {selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1)} Design
                    </h4>
                    <div className="rounded-xl overflow-hidden shadow-lg">
                      <img
                        src={generatedImage}
                        alt="Generated room design"
                        className="w-full h-48 object-cover"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                originalImage && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-600 mb-2">Uploaded Image</h4>
                    <div className="rounded-xl overflow-hidden shadow-lg">
                      <img
                        src={originalImage}
                        alt="Uploaded room"
                        className="w-full h-64 object-cover"
                      />
                    </div>
                  </div>
                )
              )}

              {/* Download Button */}
              {generatedImage && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex justify-center"
                >
                  <Button
                    onClick={onDownload}
                    className="generate-btn text-white font-semibold py-3 px-8 rounded-xl"
                    size="lg"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download Result
                  </Button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Empty State */}
      {!originalImage && !isProcessing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="result-container rounded-2xl p-8 text-center"
        >
          <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center">
            <ImageIcon className="w-12 h-12 text-indigo-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Ready to Transform Your Space?
          </h3>
          <p className="text-gray-600">
            Upload a room photo and select a theme to see the magic happen!
          </p>
        </motion.div>
      )}
    </div>
  );
};

export default ResultDisplay;
